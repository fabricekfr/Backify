﻿using System.Collections.Generic;
using System.Windows.Media;
using SciChart.Charting.Model.DataSeries;
using SciChart.Charting.Visuals.PaletteProviders;
using SciChart.Charting.Visuals.RenderableSeries;

namespace Presentation.ViewModels
{
    public class CustomPaletteProvider : IStrokePaletteProvider
    {
        private List<Color> availablesColors = new List<Color>()
        {
            Colors.Red,
            Colors.Yellow,
            Colors.Green,
            Colors.Orange,
            Colors.Blue
        };

        public Color? OverrideStrokeColor(IRenderableSeries series,
                               int index, IPointMetadata metadata)
        {
            return availablesColors[index%5];
        }

        public void OnBeginSeriesDraw(IRenderableSeries rSeries)
        {            
        }
    }
}