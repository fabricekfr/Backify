﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for SeriesBindingView.xaml
    /// </summary>
    public partial class MillionPointSeriesBindingView : UserControl
    {
        public MillionPointSeriesBindingView()
        {
            InitializeComponent();
        }
    }
}
