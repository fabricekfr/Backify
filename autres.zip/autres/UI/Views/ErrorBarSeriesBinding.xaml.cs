﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for SeriesBindingView.xaml
    /// </summary>
    public partial class ErrorBarSeriesBindingView : UserControl
    {
        public ErrorBarSeriesBindingView()
        {
            InitializeComponent();
        }
    }
}
