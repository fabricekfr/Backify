﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using ClientModel;
using Presentation.ViewModels;
using SciChart.Charting.ChartModifiers;
using SciChart.Charting.Model.DataSeries;
using SciChart.Charting.Utility;
using SciChart.Charting.Visuals;
using SciChart.Charting.Visuals.RenderableSeries;
using SciChart.Core.Utility.Mouse;
using SciChart.Drawing.Utility;

namespace Abt.Controls.SciChart.Wpf.TestSuite.ExampleSandbox.CustomModifiers
{
    //http://support.scichart.com/index.php?/Knowledgebase/Article/View/17255/32/custom-chartmodifiers---part-6---select-data-points-via-mouse-drag
    public class LassoDataPointSelectionModifier : ChartModifierBase
    {
        public static readonly DependencyProperty SelectionPolygonStyleProperty = DependencyProperty.Register(
            "SelectionPolygonStyle", typeof(Style), typeof(LassoDataPointSelectionModifier), new PropertyMetadata(default(Style)));

        public Style SelectionPolygonStyle
        {
            get { return (Style)GetValue(SelectionPolygonStyleProperty); }
            set { SetValue(SelectionPolygonStyleProperty, value); }
        }

        public static readonly DependencyProperty SelectedPointsProperty = DependencyProperty.Register(
                "SelectedPoints", typeof(IDictionary<IRenderableSeries, IList<DataPoint>>), typeof(LassoDataPointSelectionModifier), new PropertyMetadata(default(IDictionary<IRenderableSeries, IList<DataPoint>>)));

        public IDictionary<IRenderableSeries, IList<DataPoint>> SelectedPoints
        {
            get { return (IDictionary<IRenderableSeries, IList<DataPoint>>)GetValue(SelectedPointsProperty); }
            set { SetValue(SelectedPointsProperty, value); }
        }

        /// <summary>
        /// reticule
        /// </summary>
        private Polygon _polygon;

        private bool _isDragging;
        private Point _startPoint;
        private Point _endPoint;

        /// <summary>
        /// Gets whether the user is currently dragging the mouse
        /// </summary>
        public bool IsDragging
        {
            get { return _isDragging; }
        }

        /// <summary>
        /// Called when the Chart Modifier is attached to the Chart Surface
        /// </summary>
        /// <remarks></remarks>
        public override void OnAttached()
        {
            base.OnAttached();

            ClearReticule();
        }

        /// <summary>
        /// Called when the Chart Modifier is detached from the Chart Surface
        /// </summary>
        /// <remarks></remarks>
        public override void OnDetached()
        {
            base.OnDetached();

            ClearReticule();
        }

        public override void OnModifierMouseDown(ModifierMouseArgs e)
        {
            base.OnModifierMouseDown(e);

            // Check the ExecuteOn property and if we are already dragging. If so, exit
            if (_isDragging || !MatchesExecuteOn(e.MouseButtons, ExecuteOn))
                return;

            // Check the mouse point was inside the ModifierSurface (the central chart area). If not, exit
            var modifierSurfaceBounds = ModifierSurface.GetBoundsRelativeTo(RootGrid);
            if (!modifierSurfaceBounds.Contains(e.MousePoint))
            {
                return;
            }

            // Capture the mouse, so if mouse goes out of bounds, we retain mouse events
            if (e.IsMaster)
                ModifierSurface.CaptureMouse();

            // Translate the mouse point (which is in RootGrid coordiantes) relative to the ModifierSurface
            // This accounts for any offset due to left Y-Axis
            var ptTrans = GetPointRelativeTo(e.MousePoint, ModifierSurface);

            _startPoint = ptTrans;
            _polygon = new Polygon
            {
                Style = SelectionPolygonStyle,
            };

            // Update the zoom recticule position            
            _polygon.Points.Add(ptTrans);


            // Add the zoom reticule to the ModifierSurface - a canvas over the chart
            ModifierSurface.Children.Add(_polygon);
            

            // Set flag that a drag has begun
            _isDragging = true;
        }

        public override void OnModifierMouseMove(ModifierMouseArgs e)
        {
            if (!_isDragging)
                return;

            base.OnModifierMouseMove(e);
            e.Handled = true;

            // Translate the mouse point (which is in RootGrid coordiantes) relative to the ModifierSurface
            // This accounts for any offset due to left Y-Axis
            var ptTrans = GetPointRelativeTo(e.MousePoint, ModifierSurface);

            // Update the zoom recticule position
            _polygon.Points.Add(ptTrans);
        }

        public override void OnModifierMouseUp(ModifierMouseArgs e)
        {
            if (!_isDragging)
                return;

            base.OnModifierMouseUp(e);

            // Translate the mouse point (which is in RootGrid coordiantes) relative to the ModifierSurface
            // This accounts for any offset due to left Y-Axis
            var ptTrans = GetPointRelativeTo(e.MousePoint, ModifierSurface);

            _endPoint = e.MousePoint;


            double distanceDragged = PointUtil.Distance(_startPoint, ptTrans);
            if (distanceDragged > 10.0)
            {
                PerformSelection();
                e.Handled = true;
            }

            ClearReticule();
            _isDragging = false;

            if (e.IsMaster)
                ModifierSurface.ReleaseMouseCapture();
        }

        private void ClearReticule()
        {
            if (ModifierSurface != null && _polygon != null)
            {
                ModifierSurface.Children.Remove(_polygon);
                _polygon = null;
                _isDragging = false;
            }
        }

        private void PerformSelection()
        {
            var dataPoints = new Dictionary<IRenderableSeries, IList<DataPoint>>();

            foreach (var serie in base.ParentSurface.RenderableSeries)
            {
                dataPoints.Add(serie, new List<DataPoint>());

                var dataSerie = serie.DataSeries;
                var polygonPoints = new List<Point>();
                var xCalc = serie.XAxis.GetCurrentCoordinateCalculator();
                var yCalc = serie.YAxis.GetCurrentCoordinateCalculator();
                foreach (var point in _polygon.Points)
                {
                    var x = xCalc.GetDataValue(point.X);
                    var y = yCalc.GetDataValue(point.Y);
                    polygonPoints.Add(new Point(x, y));
                }
                                
                for (int i = 0; i < dataSerie.Count; i++)
                {
                    
                    var currentPoint = new Point(((DateTime)dataSerie.XValues[i]).Ticks, (double)dataSerie.YValues[i]);
                    if (IsPointInPolygon(polygonPoints, currentPoint))
                    {
                        dataPoints[serie].Add(new DataPoint() { Index = i, XValue = currentPoint.X, YValue = currentPoint.Y });
                    }
                }
            }

            this.SelectedPoints = dataPoints;

            this.ParentSurface.InvalidateElement();
        }

        public bool IsPointInPolygon(List<Point> polygon, Point testPoint)
        {
            bool result = false;
            if (polygon == null)
                return result;
            int j = polygon.Count() - 1;
            for (int i = 0; i < polygon.Count(); i++)
            {
                if (polygon[i].Y < testPoint.Y && polygon[j].Y >= testPoint.Y || polygon[j].Y < testPoint.Y && polygon[i].Y >= testPoint.Y)
                {
                    if (polygon[i].X + (testPoint.Y - polygon[i].Y) / (polygon[j].Y - polygon[i].Y) * (polygon[j].X - polygon[i].X) < testPoint.X)
                    {
                        result = !result;
                    }
                }
                j = i;
            }
            return result;
        }

        /// <summary>
        /// Called when the parent <see cref="SciChartSurface" /> is rendered. Here is where we draw selected points
        /// </summary>
        /// <param name="e">The <see cref="SciChartRenderedMessage" /> which contains the event arg data</param>
        public override void OnParentSurfaceRendered(SciChartRenderedMessage e)
        {
            base.OnParentSurfaceRendered(e);

            var selectedPoints = this.SelectedPoints;
            if (selectedPoints == null) return;

            double size = 12;

            // Create Fill brush for the point marker
            using (var fill = e.RenderContext.CreateBrush(Colors.Orange))
            {
                // Iterating over renderable series
                foreach (var renderSeries in selectedPoints.Keys)
                {
                    // Create stroke pen based on r-series color
                    using (var stroke = e.RenderContext.CreatePen(Colors.LightSkyBlue, true, 1.0f))
                    {
                        // We need XAxis/YAxis.GetCurrentCoordinateCalculator() from the current series (as they can be per-series)
                        // to convert data points to pixel coords
                        var xAxis = renderSeries.XAxis;
                        var yAxis = renderSeries.YAxis;
                        var xCalc = xAxis.GetCurrentCoordinateCalculator();
                        var yCalc = yAxis.GetCurrentCoordinateCalculator();

                        var pointList = selectedPoints[renderSeries];

                        // Iterate over the selected points
                        foreach (var point in pointList)
                        {
                            // Draw the selected point marker
                            e.RenderContext.DrawEllipse(
                                stroke,
                                fill,
                                new Point(xCalc.GetCoordinate(point.XValue), yCalc.GetCoordinate(point.YValue)),
                                size,
                                size);
                        }
                    }
                }
            }
        }

    }
}