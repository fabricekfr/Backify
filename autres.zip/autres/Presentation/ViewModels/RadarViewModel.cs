﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using System.Windows.Media;
using DataAccess;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using SciChart.Charting.ChartModifiers;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;
using SciChart.Charting.Visuals.PointMarkers;

namespace Presentation.ViewModels
{
    
    public class RadarViewModel : ViewModelBase
    {
        private XyDataSeries<double, double> _mySerie;
        public XyDataSeries<double, double> MySerie
        {
            get { return _mySerie; }
            set
            {
                _mySerie = value;
                RaisePropertyChanged(() => MySerie);
            }
        }

        public XyDataSeries<double, double> MinSerie { get; set; }
        public XyDataSeries<double, double> MaxSerie { get; set; }

        public RadarViewModel()
        {
            var dataService = new DesignDataService();
            var data = dataService.GetData().ToList();

            MySerie = new XyDataSeries<double, double>();
            MySerie.Append(0, 0.1);
            MySerie.Append(1, 0.2);
            MySerie.Append(2, 0.3);
            MySerie.Append(3, 0.4);
            MySerie.Append(4, 0.5);
            MySerie.Append(5, 0.6);
            MySerie.Append(6, 0.7);
            MySerie.Append(7, 0.8);

            MinSerie = new XyDataSeries<double, double>();
            MinSerie.Append(0, 0.3);
            MinSerie.Append(1, 0.3);
            MinSerie.Append(2, 0.3);
            MinSerie.Append(3, 0.3);
            MinSerie.Append(4, 0.3);
            MinSerie.Append(5, 0.3);
            MinSerie.Append(6, 0.3);
            MinSerie.Append(7, 0.3);

            MaxSerie = new XyDataSeries<double, double>();
            MaxSerie.Append(0, 0.9);
            MaxSerie.Append(1, 0.9);
            MaxSerie.Append(2, 0.9);
            MaxSerie.Append(3, 0.9);
            MaxSerie.Append(4, 0.9);
            MaxSerie.Append(5, 0.9);
            MaxSerie.Append(6, 0.9);
            MaxSerie.Append(7, 0.9);
        }      

    }
}