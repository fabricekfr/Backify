﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for SeriesBindingView.xaml
    /// </summary>
    public partial class LassoPointSelectionView : UserControl
    {
        public LassoPointSelectionView()
        {
            InitializeComponent();
        }
        
    }
}
