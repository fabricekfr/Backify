﻿namespace ClientModel
{
    public struct DataPoint
    {
        public double XValue;
        public double YValue;
        public int Index;
    }
}