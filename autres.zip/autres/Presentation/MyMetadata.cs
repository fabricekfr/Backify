﻿using System.ComponentModel;
using SciChart.Charting.Model.DataSeries;

namespace Presentation
{
    public class MyMetadata : IPointMetadata
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public bool IsSelected { get; set; }
    }
}