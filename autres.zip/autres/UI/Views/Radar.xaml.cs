﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for SeriesBindingView.xaml
    /// </summary>
    public partial class RadarView : UserControl
    {
        public RadarView()
        {
            InitializeComponent();
        }
    }
}
