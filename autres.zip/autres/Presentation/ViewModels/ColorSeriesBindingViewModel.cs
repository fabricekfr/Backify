﻿using System;
using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;

namespace Presentation.ViewModels
{
    public class ColorSeriesBindingViewModel : ViewModelBase
    {
        public ObservableCollection<IRenderableSeriesViewModel> RenderableSeriesViewModels { get; set; }

        public ColorSeriesBindingViewModel()
        {
            RenderableSeriesViewModels = new ObservableCollection<IRenderableSeriesViewModel>();            

            var customPaletteProvider = new CustomPaletteProvider();
            
            var random = new Random();
            for (int i = 0; i < 25; i++)
            {                
                var serie = new XyDataSeries<DateTime, double>();
                for (int j = 1; j < 30; j++)
                {
                    serie.Append(new DateTime(2014,1,j), random.NextDouble() * 20 + 100);
                }

                var scatterVM = new LineRenderableSeriesViewModel() {DataSeries = serie, IsVisible = true, PaletteProvider = customPaletteProvider};
                RenderableSeriesViewModels.Add(scatterVM);
            }
        }

    }
}