﻿using System;
using SciChart.Charting.Visuals.Axes.LabelProviders;

namespace UI
{
    public class PolarLabelProvider : NumericLabelProvider
    {
        public override string FormatLabel(IComparable dataValue)
        {
            // Note: Implement as you wish, converting Data-Value to string 
            if ((double)dataValue == 0.0) return "A";
            if ((double)dataValue == 1.0) return "B";
            if ((double)dataValue == 2.0) return "C";
            if ((double)dataValue == 3.0) return "D";
            if ((double)dataValue == 4.0) return "E";
            if ((double)dataValue == 5.0) return "F";
            if ((double)dataValue == 6.0) return "G";
            if ((double)dataValue == 7.0) return "H";
            return "";

            // NOTES:
            // dataValue is always a double.
            // For a NumericAxis this is the double-representation of the data
            // For a DateTimeAxis, the conversion to DateTime is new DateTime((long)dataValue)
            // For a TimeSpanAxis the conversion to TimeSpan is new TimeSpan((long)dataValue)
            // For a CategoryDateTimeAxis, dataValue is the index to the data-series
        }

        /// <summary>
        /// Formats a label for the cursor, from the specified data-value passed in
        /// </summary>
        /// <param name="dataValue">The data-value to format</param>
        /// <returns>
        /// The formatted cursor label string
        /// </returns>
        public override string FormatCursorLabel(IComparable dataValue)
        {
            // Note: Implement as you wish, converting Data-Value to string            
            if ((double)dataValue == 0.0) return "A";
            if ((double)dataValue == 1.0) return "B";
            if ((double)dataValue == 2.0) return "C";
            if ((double)dataValue == 3.0) return "D";
            if ((double)dataValue == 4.0) return "E";
            if ((double)dataValue == 5.0) return "F";
            if ((double)dataValue == 6.0) return "G";
            if ((double)dataValue == 7.0) return "H";

            return "";

            // NOTES:
            // dataValue is always a double.
            // For a NumericAxis this is the double-representation of the data
            // For a DateTimeAxis, the conversion to DateTime is new DateTime((long)dataValue)
            // For a TimeSpanAxis the conversion to TimeSpan is new TimeSpan((long)dataValue)
            // For a CategoryDateTimeAxis, dataValue is the index to the data-series
        }
    }
}