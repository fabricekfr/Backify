﻿using System;
using SciChart.Charting.Visuals.Axes.LabelProviders;

namespace UI
{
    //https://www.scichart.com/documentation/v4.x/webframe.html#Axis%20Labels%20-%20LabelProvider%20API.html
    public class CategoricalDateTimeLabelProvider: DateTimeLabelProvider
    {
        public override string FormatLabel(IComparable dataValue)
        {            
            // Note: Implement as you wish, converting Data-Value to string
            if((DateTime)dataValue ==new DateTime(2014,1,1)) return "Date 1";
            if ((DateTime)dataValue == new DateTime(2014, 1, 2)) return "Date 2";
            if ((DateTime)dataValue == new DateTime(2014, 1, 3)) return "Date 3";
            if ((DateTime)dataValue == new DateTime(2014, 1, 4)) return "Date 4";
            return "";

            // NOTES:
            // dataValue is always a double.
            // For a NumericAxis this is the double-representation of the data
            // For a DateTimeAxis, the conversion to DateTime is new DateTime((long)dataValue)
            // For a TimeSpanAxis the conversion to TimeSpan is new TimeSpan((long)dataValue)
            // For a CategoryDateTimeAxis, dataValue is the index to the data-series
        }

        /// <summary>
        /// Formats a label for the cursor, from the specified data-value passed in
        /// </summary>
        /// <param name="dataValue">The data-value to format</param>
        /// <returns>
        /// The formatted cursor label string
        /// </returns>
        public override string FormatCursorLabel(IComparable dataValue)
        {
            // Note: Implement as you wish, converting Data-Value to string
            if ((DateTime)dataValue == new DateTime(2014, 1, 1)) return "DATE 1";
            if ((DateTime)dataValue == new DateTime(2014, 1, 2)) return "DATE 2";
            if ((DateTime)dataValue == new DateTime(2014, 1, 3)) return "DATE 3";
            if ((DateTime)dataValue == new DateTime(2014, 1, 4)) return "DATE 4";
            return "";

            // NOTES:
            // dataValue is always a double.
            // For a NumericAxis this is the double-representation of the data
            // For a DateTimeAxis, the conversion to DateTime is new DateTime((long)dataValue)
            // For a TimeSpanAxis the conversion to TimeSpan is new TimeSpan((long)dataValue)
            // For a CategoryDateTimeAxis, dataValue is the index to the data-series
        }
    }
}