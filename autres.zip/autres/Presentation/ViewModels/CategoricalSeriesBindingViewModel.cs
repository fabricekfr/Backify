﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;
using SciChart.Charting.Visuals.PointMarkers;

namespace Presentation.ViewModels
{
    public class CategoricalSeriesBindingViewModel : ViewModelBase
    {
        public Dictionary<int,string> MyYLabelCategories { get; set; }
        public Dictionary<DateTime, string> MyXLabelCategories { get; set; }

        public ObservableCollection<IRenderableSeriesViewModel> RenderableSeriesViewModels { get; set; }

        public CategoricalSeriesBindingViewModel()
        {
            var mountainDataSeries = new XyDataSeries<DateTime, double>();
            mountainDataSeries.SeriesName = "Mountain";
            
            var start = new DateTime(2014, 1, 1);
            for (int i = 0; i < 4; i++)
            {
                mountainDataSeries.Append(start.AddDays(i), i);                
            }

            MyYLabelCategories = new Dictionary<int, string>();
            MyXLabelCategories = new Dictionary<DateTime, string>();
            MyYLabelCategories.Add(0,"A");
            MyYLabelCategories.Add(1, "B");
            MyYLabelCategories.Add(2, "C");
            MyYLabelCategories.Add(3, "D");
            MyXLabelCategories.Add(new DateTime(2014, 1, 1), "Date 1");
            MyXLabelCategories.Add(new DateTime(2014, 1, 2), "Date 2");
            MyXLabelCategories.Add(new DateTime(2014, 1, 3), "Date 3");
            MyXLabelCategories.Add(new DateTime(2014, 1, 4), "Date 4");

            var marker = new EllipsePointMarker();
            marker.StrokeThickness = 2;   
            RenderableSeriesViewModels = new ObservableCollection<IRenderableSeriesViewModel>()
            {
                new XyScatterRenderableSeriesViewModel() {DataSeries = mountainDataSeries, IsVisible=true, PointMarker=marker},
            };



        }
        

    }
}