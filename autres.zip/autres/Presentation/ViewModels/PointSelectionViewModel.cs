﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using System.Windows.Media;
using ClientModel;
using DataAccess;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using SciChart.Charting.ChartModifiers;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;
using SciChart.Charting.Visuals.PointMarkers;
using SciChart.Charting.Visuals.RenderableSeries;

namespace Presentation.ViewModels
{
    public class PointSelectionViewModel : ViewModelBase
    {
        private ObservableCollection<DataPointInfo> _SelectedPoints;

        private RelayCommand<object> _ContributeCommand;
        public ICommand ContributeCommand => _ContributeCommand ?? (_ContributeCommand = new RelayCommand<object>(Contribute));

        private RelayCommand<object> _SelectionCommand;
        public ICommand SelectionChangedCommand => _SelectionCommand ?? (_SelectionCommand = new RelayCommand<object>(Selection));
       

        private XyDataSeries<DateTime, double> _mySerie;

        public XyDataSeries<DateTime, double> MySerie
        {
            get { return _mySerie; }
            set
            {
                _mySerie = value;
                RaisePropertyChanged(() => MySerie);
            }
        }

        public PointSelectionViewModel()
        {
            var dataService = new DesignDataService();
            var data = dataService.GetData().ToList();

            MySerie = new XyDataSeries<DateTime, double>();
            MySerie.Append(data.Select(d => d.Date), data.Select(d => d.BodyFat), data.Select((d) => new MyMetadata {IsSelected = false}));
        }



        private void Contribute(object mouseEventArgs)
        {
            var selection = MySerie.Metadata.Where(m => m.IsSelected);

            if(_SelectedPoints!=null && _SelectedPoints.Count!=0)
                Console.WriteLine(_SelectedPoints.Count);
        }

        

        private void Selection(object selectionArgs)
        {
            _SelectedPoints = (ObservableCollection<DataPointInfo>) selectionArgs;
        }

    }
}