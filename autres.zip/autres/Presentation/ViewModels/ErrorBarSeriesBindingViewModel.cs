﻿using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;

namespace Presentation.ViewModels
{
    public class ErrorBarSeriesBindingViewModel : ViewModelBase
    {
        public ObservableCollection<IRenderableSeriesViewModel> RenderableSeriesViewModels { get; set; }

        public ErrorBarSeriesBindingViewModel()
        {
            var columnSerie = new XyDataSeries<int, double>();
            columnSerie.SeriesName = "Column";
            columnSerie.Append(1, 8);            
            columnSerie.Append(2, 5);
            columnSerie.Append(3, 9);

            var errorSerie = new HlcDataSeries<double,double>();
            errorSerie.SeriesName = "Error";
            errorSerie.Append(1, 8, 10, 5);
            errorSerie.Append(2, 5, 6, 4);
            errorSerie.Append(3, 9, 10, 6);

            RenderableSeriesViewModels = new ObservableCollection<IRenderableSeriesViewModel>()
            {                
                new ColumnRenderableSeriesViewModel() {DataSeries = columnSerie, IsVisible=true},
                new ErrorBarsRenderableSeriesViewModel() {DataSeries = errorSerie, IsVisible=true},                
            };

        }
       

        

    }
}