﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Media;
using GalaSoft.MvvmLight;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;
using SciChart.Charting.Visuals.PointMarkers;

namespace Presentation.ViewModels
{
    public class MillionPointSeriesBindingViewModel : ViewModelBase
    {
        private Color[] _Colors = new Color[] {Colors.Blue,Colors.DarkOrange, Colors.Red, Colors.Green, Colors.LightSalmon, Colors.GreenYellow};
        public ObservableCollection<IRenderableSeriesViewModel> RenderableSeriesViewModels { get; set; }

        public MillionPointSeriesBindingViewModel()
        {
            RenderableSeriesViewModels = new ObservableCollection<IRenderableSeriesViewModel>();



            for (int i = 0; i < 5; i++)
            {                
                var serie = new XyDataSeries<DateTime, double>();
                
                var date = new DateTime(2014,01,01);
                for (int j = 1; j < 1000000; j++)
                {
                    serie.Append(date.AddMinutes(j), j*i);
                }

                var marker = new EllipsePointMarker();
                marker.StrokeThickness = 3;
                marker.Fill = _Colors[i + 1];
                marker.Stroke = Colors.Transparent;
                marker.Width = 3;
                marker.Height = 3;
                var scatterVM = new XyScatterRenderableSeriesViewModel() {DataSeries = serie, IsVisible = true, PointMarker = marker};
                RenderableSeriesViewModels.Add(scatterVM);
            }
        }

    }
}