﻿using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using SciChart.Charting.ChartModifiers;

namespace UI
{
    public class SelectionModifierExtension
    {
        public static readonly DependencyProperty SelectionChangedCommandProperty = DependencyProperty.RegisterAttached(
            "SelectionChangedCommand", typeof(ICommand), typeof(SelectionModifierExtension), new PropertyMetadata(default(ICommand), OnValueChanged));

        private static void OnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var newModifier = d as DataPointSelectionModifier;
            if (newModifier != null)
            {
                newModifier.SelectionChanged += (s, arg) =>
                {                    
                    var command = e.NewValue as ICommand;
                    if (command != null)
                    {
                        command.Execute(((DataPointSelectionModifier)s).SelectedPointMarkers);
                    }
                };
            }
        }

        public static void SetSelectionChangedCommand(DependencyObject element, ICommand value)
        {
            element.SetValue(SelectionChangedCommandProperty, value);
        }

        public static ICommand GetSelectionChangedCommand(DependencyObject element)
        {
            return (ICommand)element.GetValue(SelectionChangedCommandProperty);
        }
    }
}