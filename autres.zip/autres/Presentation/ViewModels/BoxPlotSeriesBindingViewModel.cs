﻿using System;
using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;

namespace Presentation.ViewModels
{
    public class BoxPlotSeriesBindingViewModel : ViewModelBase
    {
        public ObservableCollection<IRenderableSeriesViewModel> RenderableSeriesViewModels { get; set; }

        public BoxPlotSeriesBindingViewModel()
        {
            var boxDataSeries = new BoxPlotDataSeries<DateTime, double>();
            boxDataSeries.SeriesName = "BoxPlot";
            boxDataSeries.Append(new DateTime(2014, 01, 01), 5, 1, 4, 6, 10);            
            boxDataSeries.Append(new DateTime(2014, 01, 02), 5.5, 2, 4, 8, 10);
            boxDataSeries.Append(new DateTime(2014, 01, 03), 5.5, 3, 5, 6, 8);

            var boxDataSeries2 = new BoxPlotDataSeries<DateTime, double>();
            boxDataSeries2.SeriesName = "BoxPlot";
            boxDataSeries2.Append(new DateTime(2014, 01, 01, 6, 0, 0), 4, 0.5, 3, 7, 9);
            boxDataSeries2.Append(new DateTime(2014, 01, 02, 6, 0, 0), 4, 0.5, 3, 7, 9);
            boxDataSeries2.Append(new DateTime(2014, 01, 03, 6, 0, 0), 4, 0.5, 3, 7, 9);

            var outsideValues = new XyDataSeries<DateTime, double>();
            outsideValues.Append(new DateTime(2014,01,01), 15);
            outsideValues.Append(new DateTime(2014, 01, 02), 12);
            outsideValues.Append(new DateTime(2014, 01, 02), 14);

            RenderableSeriesViewModels = new ObservableCollection<IRenderableSeriesViewModel>()
            {                
                new BoxPlotRenderableSeriesViewModel() {DataSeries = boxDataSeries, IsVisible=true},
                new BoxPlotRenderableSeriesViewModel() {DataSeries = boxDataSeries2, IsVisible=true},
                new XyScatterRenderableSeriesViewModel() {DataSeries = outsideValues, IsVisible=true, StyleKey = "LineSeriesStyle0"}
            };

        }
       

        

    }
}