﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using System.Windows.Media;
using ClientModel;
using DataAccess;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using SciChart.Charting.ChartModifiers;
using SciChart.Charting.Model.ChartSeries;
using SciChart.Charting.Model.DataSeries;
using SciChart.Charting.Visuals.PointMarkers;
using SciChart.Charting.Visuals.RenderableSeries;

namespace Presentation.ViewModels
{    
    public class LassoPointSelectionViewModel : ViewModelBase
    {
        private RelayCommand<object> _ContributeCommand;
        public ICommand ContributeCommand => _ContributeCommand ?? (_ContributeCommand = new RelayCommand<object>(Contribute));


        private IDictionary<IRenderableSeries, IList<DataPoint>> _selectedDataPoints;

        /// <summary>
        /// Gets or sets the SelectedDataPoints. This is bound to SimpleDataPointSelectionModifier.SelectedPoints
        /// </summary>
        public IDictionary<IRenderableSeries, IList<DataPoint>> SelectedDataPoints
        {
            get { return _selectedDataPoints; }
            set
            {
                _selectedDataPoints = value;
            }
        }

        private XyDataSeries<DateTime, double> _mySerie;

        public XyDataSeries<DateTime, double> MySerie
        {
            get { return _mySerie; }
            set
            {
                _mySerie = value;
                RaisePropertyChanged(() => MySerie);
            }
        }

        public LassoPointSelectionViewModel()
        {
            var dataService = new DesignDataService();
            var data = dataService.GetData().ToList();

            MySerie = new XyDataSeries<DateTime, double>();
            MySerie.Append(data.Select(d => d.Date), data.Select(d => d.BodyFat), data.Select((d) => new MyMetadata {IsSelected = false}));
        }



        private void Contribute(object mouseEventArgs)
        {
            if (SelectedDataPoints == null) return;

            foreach (var keyValue in SelectedDataPoints)
            {
                Console.WriteLine(keyValue.Value.Count);
            }
        }
        

    }
}